<?php
class FM_TicketDetails extends BizForm 
{ 
   private $m_AuditDataObj = "trac.DO_TicketChange";
   
   
   /*
    * Save basic ticket information than log to audit table
    * 
    * @return HTML string or False on error
    */
   public function SaveRecord()
   {
      if ($this->m_Mode == MODE_N)
         return parent::SaveRecord();
      
      //Disable ReRender while partially saving record
      $this->m_ReRenderOn = false;
      $ok = parent::SaveRecord();
      if ($ok != NULL)
          return false;          
      $this->m_Mode = MODE_E;    //Return to Edit mode until the end of the save function              
      $this->m_ReRenderOn = true; //Re-enable ReRender
      
      global $g_BizSystem;
      // get audit dataobj
      $auditDataObj = $g_BizSystem->GetObjectFactory()->GetObject($this->m_AuditDataObj);
      if (!$auditDataObj) return false;
      
      // get the source dataobj
      $srcDataObj = $this->GetDataObj();
      if (!$srcDataObj) return false;
      
      $author = $g_BizSystem->GetClientProxy()->GetFormInputs("editor_name");
      $time = date("Y-m-d H:i:s");
      foreach ($srcDataObj->m_BizRecord as $fld)
      {
         if ($fld->m_OldValue == $fld->m_Value || trim($fld->m_OldValue) == trim($fld->m_Value) || stripcslashes($fld->m_OldValue) == stripcslashes($fld->m_Value))
            continue;
         
         $dataRec = new DataRecord(null, $auditDataObj); 
         $dataRec['ticket'] = $srcDataObj->GetFieldValue("Id");
         $dataRec['field'] = $fld->m_Name;
         $dataRec['oldvalue'] = addslashes($fld->m_OldValue);  //This value may not yet be sanitized since it came from the database
         $dataRec['newvalue'] = $fld->m_Value;
         $dataRec['time'] = $time;
         $dataRec['author'] = $author;       
         $ok = $dataRec->Save();
         if ($ok == false){
            BizSystem::log(LOG_ERR, "DATAOBJ", $auditDataObj->GetErrorMessage());
            return false;
         }
      }
      
      // save comment
      $comment = $g_BizSystem->GetClientProxy()->GetFormInputs("editor_comment");
      if ($comment && $comment != "")
      {
         $dataRec = new DataRecord(null, $auditDataObj); 
         $dataRec['ticket'] = $srcDataObj->GetFieldValue("Id");
         $dataRec['field'] = 'comment';
         $dataRec['newvalue'] = $comment;
         $dataRec['time'] = $time;
         $dataRec['author'] = $author;       
         $ok = $dataRec->Save();
         if ($ok == false){
            BizSystem::log(LOG_ERR, "DATAOBJ", $auditDataObj->GetErrorMessage());
            return false;
         }
      }
      $this->m_Mode = MODE_R;         
      return $this->ReRender();
   }   
}
?>