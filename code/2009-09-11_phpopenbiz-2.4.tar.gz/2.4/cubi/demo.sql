/*
SQLyog Community Edition- MySQL GUI v8.14 
MySQL - 5.1.37 : Database - demo
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`demo` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `demo`;

/*Table structure for table `acl_action` */

DROP TABLE IF EXISTS `acl_action`;

CREATE TABLE `acl_action` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) NOT NULL DEFAULT '',
  `resource` varchar(64) NOT NULL DEFAULT '',
  `action` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

/*Data for the table `acl_action` */

insert  into `acl_action`(`id`,`module`,`resource`,`action`,`description`) values (1,'easy','event','access','access event'),(2,'easy','event','view','view event'),(3,'easy','event','create','create event'),(4,'easy','event','update','Update event'),(5,'easy','event','delete','Delete event'),(6,'easy','registration','access','access registration'),(7,'easy','registration','view','view registration'),(8,'easy','registration','create','create registration'),(9,'easy','registration','update','Update registration'),(10,'easy','registration','delete','Delete registration'),(11,'easy','attendee','access','access attendee'),(12,'easy','attendee','view','view attendee'),(13,'easy','attendee','create','create attendee'),(14,'easy','attendee','update','Update attendee'),(15,'easy','attendee','delete','Delete attendee');

/*Table structure for table `acl_role_action` */

DROP TABLE IF EXISTS `acl_role_action`;

CREATE TABLE `acl_role_action` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0',
  `access_level` int(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `action_id` (`action_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

/*Data for the table `acl_role_action` */

insert  into `acl_role_action`(`id`,`role_id`,`action_id`,`access_level`) values (1,1,3,2),(2,2,1,2),(18,1,1,1),(19,1,2,1),(20,1,4,2),(21,1,5,0);

/*Table structure for table `attach` */

DROP TABLE IF EXISTS `attach`;

CREATE TABLE `attach` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `PARENT_ID` varchar(20) NOT NULL DEFAULT '',
  `NAME` varchar(50) NOT NULL DEFAULT '',
  `SIZE` varchar(20) DEFAULT NULL,
  `TYPE` varchar(40) DEFAULT NULL,
  `LOCATION` varchar(50) DEFAULT NULL,
  `DATA` mediumblob,
  PRIMARY KEY (`SYSID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `attach` */

/*Table structure for table `attendee` */

DROP TABLE IF EXISTS `attendee`;

CREATE TABLE `attendee` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `LASTNAME` varchar(30) NOT NULL DEFAULT '',
  `FIRSTNAME` varchar(30) NOT NULL DEFAULT '',
  `OTHERNAME` varchar(50) DEFAULT NULL,
  `PHONE` varchar(20) DEFAULT NULL,
  `EMAIL` varchar(30) DEFAULT NULL,
  `ADDRESS` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `PHOTO` mediumblob,
  `TYPE` varchar(20) DEFAULT NULL,
  `UPORG_ID` varchar(20) DEFAULT NULL,
  `CHILD_FLAG` char(1) DEFAULT NULL,
  PRIMARY KEY (`SYSID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `attendee` */

insert  into `attendee`(`SYSID`,`LASTNAME`,`FIRSTNAME`,`OTHERNAME`,`PHONE`,`EMAIL`,`ADDRESS`,`DESCRIPTION`,`PHOTO`,`TYPE`,`UPORG_ID`,`CHILD_FLAG`) values ('ATD_1','Liu','Michael','Will','','mike@yahoo.com','','','','','',''),('ATD_2','Houston','Alan','Houston','6501111001','ahouston@yahoo.com','','','','Individual','',''),('ATD_6','Smith','Andy','obposi_6','','asmith@yahoo.com','','','','Individual','',''),('ATD_4','Lee','Pete','obposi_6','4081112100','plee@yahoo.com','','','','Individual','',''),('ATD_5','Lau','Frank','??','4081112100','flau@yahoo.com','','','','Individual','',''),('ATD_7','Monk','Steve','obposi_','','smonk@yahoo.com','','','','Individual','',''),('ATD_8','Louis','Jeff','obposi_4','','jlouis@yahoo.com','','','','Individual','',''),('ATD_22','Liu','Michael','obposi_4','','mliu@yahoo.com','','','','Individual','',''),('ATD_50','Liu','Michael','obposi_4','','mliu@yahoo.com','','','','Individual','','');

/*Table structure for table `audit` */

DROP TABLE IF EXISTS `audit`;

CREATE TABLE `audit` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `DATAOBJNAME` varchar(100) NOT NULL DEFAULT '',
  `OBJECTID` varchar(20) NOT NULL DEFAULT '',
  `FIELDNAME` varchar(30) NOT NULL DEFAULT '',
  `OLDVALUE` varchar(100) DEFAULT NULL,
  `NEWVALUE` varchar(100) DEFAULT NULL,
  `CHANGETIME` datetime DEFAULT NULL,
  `CHANGEBY` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`SYSID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `audit` */

insert  into `audit`(`SYSID`,`DATAOBJNAME`,`OBJECTID`,`FIELDNAME`,`OLDVALUE`,`NEWVALUE`,`CHANGETIME`,`CHANGEBY`) values ('ADT_10','demo.BOEvent','EVT_5','Name','NCCAF 2004 Basketball -4','NCCAF 2004 Basketball -5','2006-04-27 01:14:49',''),('ADT_11','demo.BOEvent','EVT_2','Name','NCCAF 2004 Badminton 10','NCCAF 2004 Badminton','2006-05-07 08:27:09',''),('ADT_12','demo.BOEvent','EVT_5','Name','NCCAF 2004 Basketball -5','NCCAF 2004 Basketball','2006-05-07 08:27:32',''),('ADT_5','demo.BOEvent','EVT_2','Name','NCCAF 2004 Badminton 1','NCCAF 2004 Badminton 10','2006-04-27 00:43:27','');

/*Table structure for table `autoincr` */

DROP TABLE IF EXISTS `autoincr`;

CREATE TABLE `autoincr` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(30) DEFAULT NULL,
  `DESCRIPTION` varchar(50) DEFAULT NULL,
  `F_ID` int(11) DEFAULT '10',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `autoincr` */

insert  into `autoincr`(`ID`,`NAME`,`DESCRIPTION`,`F_ID`) values (1,'asd1','asd',0),(2,'asd2','test',0),(3,'aa3','asd',0),(4,'aaa','aaa',0),(5,'bbb','bbb',0),(6,'aa3','asd',0),(7,'asd1','asd',0);

/*Table structure for table `calattds` */

DROP TABLE IF EXISTS `calattds`;

CREATE TABLE `calattds` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `LNAME` varchar(20) NOT NULL DEFAULT '',
  `FNAME` varchar(20) NOT NULL DEFAULT '',
  `COMPANY` varchar(30) DEFAULT NULL,
  `JOB_TITLE` varchar(30) DEFAULT NULL,
  `CONTACT` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`SYSID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `calattds` */

insert  into `calattds`(`SYSID`,`LNAME`,`FNAME`,`COMPANY`,`JOB_TITLE`,`CONTACT`) values ('ATD_1','Jordan','Micheal','TNT','Sport Commentor','mjordan@tnt.com'),('ATD_2','Johnson','Magic','','','mjohnson@coach.com'),('ATD_3','Bonds','Barry','','','');

/*Table structure for table `calevts` */

DROP TABLE IF EXISTS `calevts`;

CREATE TABLE `calevts` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `SUBJECT` varchar(20) DEFAULT NULL,
  `TYPE` varchar(20) DEFAULT NULL,
  `LOCATION` varchar(50) DEFAULT NULL,
  `NOTES` varchar(200) DEFAULT NULL,
  `STARTTIME` datetime DEFAULT NULL,
  `ENDTIME` datetime DEFAULT NULL,
  `REPEATFLAG` char(1) DEFAULT 'N',
  `REPEATCYCLE` varchar(20) DEFAULT NULL,
  `REPEATEND` datetime DEFAULT NULL,
  PRIMARY KEY (`SYSID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `calevts` */

insert  into `calevts`(`SYSID`,`SUBJECT`,`TYPE`,`LOCATION`,`NOTES`,`STARTTIME`,`ENDTIME`,`REPEATFLAG`,`REPEATCYCLE`,`REPEATEND`) values ('CAL_1','Group Meeting','Meeting','Room 101','Marketing weekly group meeting','2005-06-01 08:00:00','2005-06-01 10:30:00','','','1999-11-30 00:00:00'),('CAL_2','BT Conf call','Appointment','Hall 201','Conference call with BT sales','2005-06-01 09:00:00','2005-06-01 12:30:00','','','1999-11-30 00:00:00'),('CAL_14','Test week event','Appointment','Room 300','Test repeated event','2005-06-01 14:38:34','2005-06-01 16:38:34','Y','Every week','2005-08-04 16:38:35'),('CAL_16','Test day repeat','Meeting','Cafe','','2005-06-06 12:15:00','2005-06-06 13:15:00','Y','Every day','2005-06-10 23:44:16'),('CAL_17','Test month repeat','Meeting','Conference 300','Monthly meeting','2005-06-07 09:10:28','2005-06-07 10:10:28','Y','Every month','2005-10-01 00:10:28'),('CAL_18','Test year repeat','Birthday','','Mike birthday','2005-06-10 00:14:34','2005-06-10 00:15:34','Y','Every year','2008-09-25 00:14:34');

/*Table structure for table `calevts_attds` */

DROP TABLE IF EXISTS `calevts_attds`;

CREATE TABLE `calevts_attds` (
  `SYSID` int(20) NOT NULL AUTO_INCREMENT,
  `EVT_ID` varchar(20) NOT NULL DEFAULT '',
  `ATD_ID` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`SYSID`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `calevts_attds` */

insert  into `calevts_attds`(`SYSID`,`EVT_ID`,`ATD_ID`) values (1,'CAL_1','ATD_1'),(3,'CAL_1','ATD_3'),(4,'CAL_2','ATD_1'),(8,'CAL_2','ATD_2'),(9,'','ATD_1');

/*Table structure for table `compkey` */

DROP TABLE IF EXISTS `compkey`;

CREATE TABLE `compkey` (
  `LASTNAME` char(30) NOT NULL DEFAULT '',
  `FIRSTNAME` char(30) NOT NULL DEFAULT '',
  `AGE` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`LASTNAME`,`FIRSTNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `compkey` */

insert  into `compkey`(`LASTNAME`,`FIRSTNAME`,`AGE`) values ('aaa','eee','30'),('aaa','hhh','56'),('aaa','jjj','12');

/*Table structure for table `events` */

DROP TABLE IF EXISTS `events`;

CREATE TABLE `events` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `NAME` varchar(100) NOT NULL DEFAULT '',
  `HOST` varchar(50) NOT NULL DEFAULT '',
  `START` datetime DEFAULT NULL,
  `END` datetime DEFAULT NULL,
  `LOCATION` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SYSID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `events` */

insert  into `events`(`SYSID`,`NAME`,`HOST`,`START`,`END`,`LOCATION`,`DESCRIPTION`) values ('EVT_3','NCCAF 2004 Tennis','NCCAF','2004-06-20 10:33:51','2004-06-20 13:33:51','San Jose State Univ',''),('EVT_4','NCCAF 2004 Soccer','NCCAF','2006-10-30 23:47:56','0000-00-00 00:00:00','San Jose State Univ',''),('EVT_5','NCCAF 2004 Basketball','NCCAF','2004-11-30 09:00:00','0000-00-00 00:00:00','San Jose State Univ',''),('EVT_6','NCCAF 2004 Table Tennis','NCCAF','2004-06-19 09:00:00','2004-06-19 21:00:00','San Jose State Univ',''),('EVT_118','NCCAF 2004 Badminton','NCCAF','2004-06-20 10:33:51','2004-06-20 13:33:51','San Jose State Univ','');

/*Table structure for table `module` */

DROP TABLE IF EXISTS `module`;

CREATE TABLE `module` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `module` */

insert  into `module`(`id`,`name`,`description`) values (1,'easy','event management module'),(2,'system','system module, only administrator can access'),(3,'tool','tool module, only developers can access');

/*Table structure for table `ob_sysids` */

DROP TABLE IF EXISTS `ob_sysids`;

CREATE TABLE `ob_sysids` (
  `TABLENAME` char(20) NOT NULL DEFAULT '',
  `PREFIX` char(10) DEFAULT NULL,
  `IDBODY` int(11) DEFAULT NULL,
  PRIMARY KEY (`TABLENAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `ob_sysids` */

insert  into `ob_sysids`(`TABLENAME`,`PREFIX`,`IDBODY`) values ('events','EVT',118),('regist','REG',173),('calevts','CAL',58),('audit','ADT',12),('ob_users','USR',1),('matches','MTC',223),('schedule','SCHD',289),('sponsors','SPSR',6),('calattds','CATD',5),('attendee','ATD',53),('attach','ATCH',77);

/*Table structure for table `ob_users` */

DROP TABLE IF EXISTS `ob_users`;

CREATE TABLE `ob_users` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `USERID` varchar(15) NOT NULL DEFAULT '',
  `PASSWORD` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`SYSID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `ob_users` */

insert  into `ob_users`(`SYSID`,`USERID`,`PASSWORD`) values ('USR_1','admin','admin'),('USR_2','bill','bill');

/*Table structure for table `perm_data` */

DROP TABLE IF EXISTS `perm_data`;

CREATE TABLE `perm_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0',
  `module_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dataobject` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `allow_view` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_list` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_create` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_modify` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_delete` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_export` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_import` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `perm_data` */

/*Table structure for table `regist` */

DROP TABLE IF EXISTS `regist`;

CREATE TABLE `regist` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `ATTENDEE_ID` varchar(20) NOT NULL DEFAULT '',
  `EVENT_ID` varchar(20) NOT NULL DEFAULT '',
  `FEE` decimal(10,0) DEFAULT NULL,
  `ONSCHD_FLAG` char(1) DEFAULT NULL,
  PRIMARY KEY (`SYSID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `regist` */

insert  into `regist`(`SYSID`,`ATTENDEE_ID`,`EVENT_ID`,`FEE`,`ONSCHD_FLAG`) values ('REG_103','ATD_5','EVT_5','15',''),('REG_101','ATD_1','EVT_4','20',''),('REG_130','ATD_8','EVT_3','15',''),('REG_11','ATD_4','EVT_5','25',''),('REG_139','ATD_5','EVT_3','0','Y'),('REG_148','ATD_2','EVT_5','0',''),('REG_136','ATD_1','EVT_3',NULL,''),('REG_100','ATD_4','EVT_4',NULL,''),('REG_61','ATD_8','EVT_4',NULL,''),('REG_95','ATD_5','EVT_4',NULL,''),('REG_104','ATD_4','EVT_3',NULL,''),('REG_173','ATD_8','EVT_118','15',''),('REG_172','ATD_2','EVT_118','15',''),('REG_170','ATD_5','EVT_6','15','');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `role` */

insert  into `role`(`id`,`name`,`description`) values (1,'Administrator','System administrator'),(2,'Guest','Guest users are unregistered users'),(3,'Member','General registered users');

/*Table structure for table `sponsors` */

DROP TABLE IF EXISTS `sponsors`;

CREATE TABLE `sponsors` (
  `SYSID` varchar(20) NOT NULL DEFAULT '',
  `NAME` varchar(50) NOT NULL DEFAULT '',
  `CONTACT` varchar(100) DEFAULT NULL,
  `ADDRESS` varchar(100) DEFAULT NULL,
  `DONATION` decimal(10,0) DEFAULT NULL,
  `EXPENSE` decimal(10,0) DEFAULT NULL,
  `COMMENTS` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`SYSID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `sponsors` */

insert  into `sponsors`(`SYSID`,`NAME`,`CONTACT`,`ADDRESS`,`DONATION`,`EXPENSE`,`COMMENTS`) values ('SPSR_2','Tiger Balm','','','30000','25000',''),('SPSR_3','San Jose Mecury Daily','','','50000','45000',''),('SPSR_4','Starbucks Coffee','','','15000','20000',''),('SPSR_5','Midas Auto','','','25000','20000',''),('SPSR_6','Steves Creeks Ford','','','10000','12000','');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `enctype` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(64) DEFAULT '',
  `lastlogin` datetime DEFAULT NULL,
  `lastchange` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`id`,`username`,`password`,`enctype`,`email`,`lastlogin`,`lastchange`) values (1,'admin','d033e22ae348aeb5660fc2140aec35850c4da997','SHA1','admin@yourcompany.com',NULL,'2009-08-24 13:24:14'),(5,'rocky','5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8','SHA1','rockyswen@phpopenbiz.org',NULL,'2009-08-23 23:39:37');

/*Table structure for table `user_role` */

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `role_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `user_role` */

insert  into `user_role`(`id`,`user_id`,`role_id`) values (1,1,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
