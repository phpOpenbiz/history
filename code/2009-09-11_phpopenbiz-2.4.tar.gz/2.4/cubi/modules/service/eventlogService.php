<?php


class eventlogService
{
   
   public $m_logDataObj;
   public $m_MessageFile;
   
   function __construct(&$xmlArr)
   {      
      $this->ReadMetadata($xmlArr);
   }

   protected function ReadMetadata(&$xmlArr)
   {      
      $this->m_logDataObj 	= $xmlArr["PLUGINSERVICE"]["ATTRIBUTES"]["BIZDATAOBJ"];
      $this->m_MessageFile 	= $xmlArr["PLUGINSERVICE"]["ATTRIBUTES"]["MESSAGEFILE"];
      $this->LoadMessageFile();     
   }
   
   protected function LoadMessageFile(){
   		if(isset($this->m_MessageFile)){
   			if($this->m_MessageFile!=""){   				
   				if(is_file(APP_HOME.$this->m_MessageFile)){
   					require_once(APP_HOME.$this->m_MessageFile);
   				}
   			}
   		}
   }
   
	public function Log($eventName,$eventMessage,$eventComment=array()){
      global $g_BizSystem;

      $logDataObj = $g_BizSystem->GetObjectFactory()->GetObject($this->m_logDataObj);
      if (!$logDataObj) return false;
         
         
         $profile = $g_BizSystem->GetUserProfile();  
         $recArr['userid'] = $profile["USERID"];
         $recArr['logipaddr'] = $_SERVER['REMOTE_ADDR'];
         $recArr['logevent'] = $eventName;
         $recArr['logmessage'] = $eventMessage;
         $recArr['logcomment'] = serialize($eventComment);
         $recArr['logtimestamp'] = date("Y-m-d H:i:s");
         
         $ok = $logDataObj->InsertRecord($recArr);
         if ($ok == false){
            BizSystem::log(LOG_ERR, "EVENTLOG", $logDataObj->GetErrorMessage());
            return false;
         }		
	}
	
	public function GetEventName($eventName){
    	if(defined($eventName)){
    		$eventName = constant($eventName);
    	}	
		return I18n::getInstance()->translate($eventName);
	}
	
	public function GetLogMessage($eventMessage,$eventComment){
    	if(defined($eventMessage)){
    		$eventMessage = constant($eventMessage);
    	}	
		$eventMessage=I18n::getInstance()->translate($eventMessage);
		$eventComment=unserialize($eventComment);
		$result = vsprintf($eventMessage,$eventComment);
		return $result;		
	}
	
 public function exportCSV()
    {
    	$separator=",";
    	$ext="csv";
        ob_end_clean();
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: filename=EventLog_".date('Y-m-d') . "." . $ext);
        header("Content-Transfer-Encoding: binary");
        
        $recordList = $this->getLogData();
        foreach ($recordList as $row)
        {
            $line = "";
            foreach ($row as $cell)
                $line .= "\"" . strip_tags($cell) . "\"$separator";
            $line = rtrim($line, $separator);
            echo rtrim($line) . "\n";
        }
    }
    
    protected function getLogData()
    {
        $logDataObj = BizSystem::ObjectFactory()->GetObject($this->m_logDataObj);         
	    $recordList = array();
	    $logDataObj->FetchRecords("", $recordList);    	    		    
	    for($i=0;$i<count($recordList);$i++){    	
	    	$data[$i]['logtimestamp'] 	= $recordList[$i]['logtimestamp'];
	    	$data[$i]['logipaddr'] 		= $recordList[$i]['logipaddr'];
	    	$data[$i]['logevent'] 		= $this->GetEventName($recordList[$i]['logevent']);
	    	$data[$i]['logmessage']		= $this->GetLogMessage($recordList[$i]['logmessage'],
	    														$recordList[$i]['logcomment']);	
    		$data[$i]['logevent']		= $this->convertEncoding($data[$i]['logevent']);
    		$data[$i]['logmessage']		= $this->convertEncoding($data[$i]['logmessage']);
    		
	    }        
        return $data;         
    }	
    
    //convert encoding for Microsoft Excel, It doesnt supports UTF-8 encoding
    protected function convertEncoding($message){
    	$lang=strtolower(I18n::getInstance()->getCurrentLanguage());    	
    	switch($lang){
    		case 'zh_cn':
    			$message = iconv("UTF-8","GB2312//IGNORE",$message);    			
    			break;
    		case 'zh_tw':
    			$message = iconv("UTF-8","BIG5//IGNORE",$message);
    			break;
    	}
    	
    	return $message;
    }
}

?>