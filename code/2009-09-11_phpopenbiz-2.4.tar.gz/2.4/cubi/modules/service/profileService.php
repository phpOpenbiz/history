<?php
class profileService
{
    protected $m_Name = "ProfileService";
    protected $m_Profile;
    protected $m_profileObj;
    protected $m_userDataObj = "system.user.d_user";
    protected $m_user_roleDataObj = "system.user.d_user_role";
    
    public function __construct(&$xmlArr)
    {      
        //$this->ReadMetadata($xmlArr);
    }

    protected function ReadMetadata(&$xmlArr)
    {      
        //$this->m_profileObj = $xmlArr["PLUGINSERVICE"]["ATTRIBUTES"]["BIZDATAOBJ"];
    }
	
	public function InitProfile($username)
	{
		$this->m_Profile = $this->InitDBProfile($username); 
		BizSystem::SessionContext()->SetVar("_USER_PROFILE", $this->m_Profile);
		return $this->m_Profile;
	}

    public function GetProfile($attr=null)
    {
        if (!$this->m_Profile)
		{
			$this->m_Profile = BizSystem::SessionContext()->GetVar("_USER_PROFILE");
		}
		if (!$this->m_Profile)
			return null;
		
		if ($attr && isset($this->m_Profile[$attr]))
			return $this->m_Profile[$attr];
		
        return $this->m_Profile;
    }
    
    public function SetProfile($profile)
    {
        $this->m_Profile = $profile;
    }
   
    protected function InitDBProfile($username, $password=null)
    {
        global $g_BizSystem;
        
        // fetch user record
        $do = $g_BizSystem->GetObjectFactory()->GetObject($this->m_userDataObj);
        if (!$do)
            return false;

        $rs = $do->DirectFetch("[username]='$username'", 1);
        if (!$rs)
            return null;
        
        // set the profile array
        $userId = $rs[0]['Id'];
        $profile = $rs[0];
        
        // fetch roles and set profile roles
        $do = BizSystem::ObjectFactory()->GetObject($this->m_user_roleDataObj);
        $rs = $do->DirectFetch("[user_id]='$userId'", 1);
        if ($rs)
        {
            foreach ($rs as $rec)
            {
                $profile['roles'][] = $rec['role_id'];
                $profile['roleNames'][] = $rec['role_name'];
            }
        }
        //print_r($profile);
        return $profile;
    }

}

?>