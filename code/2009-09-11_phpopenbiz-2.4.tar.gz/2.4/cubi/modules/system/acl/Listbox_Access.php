<?PHP
/**
 * FieldControl - class FieldControl is the base class of field control who binds with a bizfield
 *
 * @package BizView
 * @author rocky swen
 * @copyright Copyright (c) 2005
 * @version 1.2
 * @access public
 */
class Listbox_Access extends Listbox
{
   /**
    * FieldControl::Render() - Draw the control according to the mode
    *
    * @returns stirng HTML text
    */
    public function Render()
    {
        // change name as name_actionid
        $elem = $this->GetFormObj()->GetElement('fld_Id');
        $aclActionId = $elem->GetValue();
        
        $sHTML = parent::Render();
        $sHTML .= "<input type='hidden' name='action_id[]' value='$aclActionId'/>";
        
        return $sHTML;
    }
}

?>
