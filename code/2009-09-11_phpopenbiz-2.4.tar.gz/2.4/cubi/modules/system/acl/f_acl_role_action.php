<?php
class f_acl_role_action extends EasyForm
{
    public function FetchDataSet()
    {
        $roleId = $this->GetRoleId();
        
        // fetch acl_action records
        $do = BizSystem::ObjectFactory()->GetObject("system.acl.d_acl_action");
        $rs = $do->DirectFetch();
        
        // fetch role and access
        $rs1 = $this->GetDataObj()->DirectFetch("[role_id]=$roleId");
        foreach ($rs1 as $rec)
        {
            $actionRoleAccess[$rec['action_id']] = $rec;
        }
        //print_r($actionRoleAccess);
        // merge 2 rs
        for ($i=0; $i<count($rs); $i++)
        {
            $actionId = $rs[$i]['Id'];
            $rs[$i]['access_level'] = "";
            if (isset($actionRoleAccess[$actionId]))
                $rs[$i]['access_level'] = $actionRoleAccess[$actionId]['access_level'];
        }
        return $rs;
    }
    
	public function SaveAccessLevel()
	{
        $roleId = $this->GetRoleId();
        // read the all access_level-actionid
        $accessLevels = BizSystem::ClientProxy()->GetFormInputs('access_level', false);
        $actionIds = BizSystem::ClientProxy()->GetFormInputs('action_id', false);
        for ($i=0; $i<count($actionIds); $i++)
        {
            $actionId = $actionIds[$i];
            $accessLevel = $accessLevels[$i];
            // if find the record, update it, or insert a new one
            try {
                $rs = $this->GetDataObj()->DirectFetch("[role_id]=$roleId AND [action_id]=$actionId", 1);
                if (count($rs) == 1)
                {
                    if ($rs[0]['access_level'] != $accessLevel) // update
                    {
                        $recArr = $rs[0];
                        $recArr['access_level'] = $accessLevel;
                        $this->GetDataObj()->UpdateRecord($recArr, $rs[0]);
                    }
                }
                else    // insert
                {
                    if ($accessLevel !== null && $accessLevel !== "")
                    {
                        $recArr = array("role_id"=>$roleId, "action_id"=>$actionId, "access_level"=>$accessLevel);
                        $this->GetDataObj()->InsertRecord($recArr);
                    }
                }
            }
            catch (BDOException $e) {
                $this->ProcessBDOException($e);
                return;
            }
        }
    }
    
    protected function GetRoleId()
    {
        return $_GET['fld:Id'];
    }
}
?>