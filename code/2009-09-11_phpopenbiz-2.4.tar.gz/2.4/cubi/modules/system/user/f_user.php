<?php
class f_user extends EasyForm
{
	protected $username;
	protected $password;
	protected $password_repeat;
	
	public function SaveRecord()
	{
		$recArr = $this->ReadInputRecord();
        
        if ($this->ValidateForm() == false)
            return;
        $recArr = $this->ReadInputRecord();
        if (count($recArr) == 0)
            return;
        

        if ($this->m_FormType == "NEW")
            $dataRec = new DataRecord(null, $this->GetDataObj());
        else
        {
            $currentRec = $this->FetchData(); 
            $dataRec = new DataRecord($currentRec, $this->GetDataObj());
        }        
        
        $old_enctype =   $dataRec['enctype'];
        foreach ($recArr as $k => $v){
            $dataRec[$k] = $v; // or $dataRec->$k = $v;
		}
		if($recArr['password']){
			$dataRec['password']=	hash(strtolower($dataRec['enctype']), $dataRec['password']);
			$dataRec['enctype']	=	strtoupper($dataRec['enctype']);
			$dataRec['lastchange'] = date("Y-m-d H:i:s");
		}else{
			$dataRec['enctype'] = $old_enctype;
		}
        $ok = $dataRec->Save();
        if (! $ok)
            return $this->ProcessDataObjError($ok);
        
        // update the active record with new update record
        //$this->GetActiveRecord();       
        $this->GetActiveRecord($dataRec["Id"]);

        // in case of popup form, close it, then rerender the parent form
        if ($this->m_ParentFormName)
        {
            $this->Close();
        
            $this->RenderParent();
        }
        
        $this->ProcessPostAction();
	}
	
	public function ValidateForm ()
    {	
    	parent::ValidateForm();
    	
    	global $g_BizSystem;
		$this->password 		= $g_BizSystem->GetClientProxy()->GetFormInputs("fld_password");
		$this->password_repeat	= $g_BizSystem->GetClientProxy()->GetFormInputs("fld_password_repeat");

		if($this->password!=$this->password_repeat){			
		    $errorFields=array( "fld_password"=>"input_error",
								"fld_password_repeat"=>"input_error");
			$error = $this->GetErrorMessage(MSG_USER_PASSWORD_NOT_MATCH);	
			$this->ProcessFormObjError($error,$errorFields);
			return false;
		}
    		
        return true;
    }
    

}
?>