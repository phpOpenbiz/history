<?php 
class f_login extends EasyForm
{
   protected $username;
   protected $password;
   private $m_hasError = false;
   
   public function Login()
   {
	  	//echo "user login"; exit;
	  	
	  	// get the username and password
		global $g_BizSystem;
		
		$this->username = $g_BizSystem->GetClientProxy()->GetFormInputs("username");
		$this->password = $g_BizSystem->GetClientProxy()->GetFormInputs("password");
	  
		$svcobj = $g_BizSystem->GetService(VALIDATE_SERVICE);
		if($svcobj->betweenLength($this->username,15,4)!=true){
			$error=sprintf(I18n::getInstance()->translate(MSG_LOGIN_WRONG_LENGTH),4,15);
			$errorFields=array( "username"=>"input_error");
			return $this->ReRenderWithError($error, $errorFields);
		}
		
		if($svcobj->betweenLength($this->password,15,4)!=true){
			$error=sprintf(I18n::getInstance()->translate(MSG_PASSWORD_WRONG_LENGTH),4,15);
		    $errorFields=array( "password"=>"input_error");
			return $this->ReRenderWithError($error, $errorFields);
		}		
		unset($svcobj);

		$svcobj 	= $g_BizSystem->GetService("authService");
		//$eventlog 	= $g_BizSystem->GetService("eventlogService");
		if ($svcobj->AuthenticateUser($this->username,$this->password)) 
		{
            // after authenticate user: 1. init profile
			$profile = $g_BizSystem->InitUserProfile($this->username);
			
			// after authenticate user: 2. insert login event
			//$logComment=array(	$this->username, $_SERVER['REMOTE_ADDR']);
			//$eventlog->log("LOGIN", "MSG_LOGIN_SUCCESSFUL", $logComment);
			
			// after authenticate user: 3. update login time in user record
	   	    //if (!$this->UpdateloginTime())
	   	    //    return false;

		    parent::ProcessPostAction();
		    return true;
		}
		else
		{ 
			/*$logComment=array($this->username,
								$_SERVER['REMOTE_ADDR'],
								$this->password);
			//$eventlog->log("LOGIN", "MSG_LOGIN_FAILED", $logComment);*/
		    $error = I18n::getInstance()->translate(MSG_LOGIN_INVALID);
		    $errorFields=array( "username"=>"err",
								"password"=>"err");
		    return $this->ReRenderWithError($error, $errorFields);
		}
   }
   
   protected function UpdateloginTime()
   {
      $userObj = BizSystem::ObjectFactory()->GetObject('system.obj.d_user');
   	try {
	   	$curRecs = $userObj->DirectFetch("[login]='".$this->username."'", 1);
	   	$dataRec = new DataRecord($curRecs[0], $userObj);
         $dataRec['lastlogin'] = date("Y-m-d H:i:s");
         $ok = $dataRec->Save();
         if (! $ok) {
            $errorMsg = $userObj->GetErrorMessage();
            BizSystem::log(LOG_ERR, "DATAOBJ", "DataObj error = ".$errorMsg);
            BizSystem::ClientProxy()->ShowErrorMessage($errorMsg);
            return false;
         }
      } catch (BDOException $e) {
          $errorMsg = $e->getMessage();
          BizSystem::log(LOG_ERR, "DATAOBJ", "DataObj error = ".$errorMsg);
          BizSystem::ClientProxy()->ShowErrorMessage($errorMsg);
          return false;
      }
      return true;
   }
   
   protected function ReRenderWithError($error,$errorFields=array())
   {
      $this->m_hasError = true;
      $recArr["fld_username"] = $this->username;
      $recArr["fld_password"] = $this->password;
      $this->SetActiveRecord($recArr);
      
      foreach ($errorFields as $ctrlname=>$error_style){
      	$ctrl = $this->GetElement($ctrlname);
      	$ctrl->m_cssClass=$error_style;
      }
      
      $txtErr_Ctrl = $this->GetElement("error_msg");
      if ($txtErr_Ctrl)
         $txtErr_Ctrl->m_Text = $error;
      return $this->ReRender();
   }
   

}  
?>