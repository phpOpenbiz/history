CREATE TABLE `user` (                                 
  `id` int(10) unsigned NOT NULL auto_increment,      
  `username` varchar(64) NOT NULL default '',              
  `password` varchar(64) NOT NULL default '',              
  `enctype` varchar(64) NOT NULL default '',              
  `email` varchar(64) default '',                       
  `theme` varchar(255) NOT NULL default '',            
  `signature` varchar(255) NOT NULL default '',        
  `created` datetime,              
  `access` datetime,               
  `login` datetime,                
  `status` tinyint(4) NOT NULL default '0',            
  `timezone` varchar(8) default NULL,                  
  `language` varchar(12) NOT NULL default '',          
  `picture` varchar(255) NOT NULL default '',                           
  `data` text,                                     
  PRIMARY KEY  (`id`),                                
  UNIQUE KEY `username` (`username`),                                                   
  KEY `email` (`email`)                                  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  

CREATE TABLE `role` (                                  
  `id` int(10) unsigned NOT NULL auto_increment,      
  `name` varchar(64) NOT NULL default '',              
  PRIMARY KEY  (`id`),  
  `description` varchar(255) default NULL,                               
  UNIQUE KEY `name` (`name`)                           
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  

CREATE TABLE `user_role` (                    
   `id` int(10) unsigned NOT NULL auto_increment,
   `user_id` int(10) unsigned NOT NULL default '0',  
   `role_id` int(10) unsigned NOT NULL default '0',  
   PRIMARY KEY  (`id`),                   
   KEY `user_id` (`user_id`),                             
   KEY `role_id` (`role_id`)                             
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  

CREATE TABLE `module` (                                  
  `id` int(10) unsigned NOT NULL auto_increment,      
  `name` varchar(64) NOT NULL default '',    
  `description` varchar(255) default NULL,           
  PRIMARY KEY  (`id`),                                
  UNIQUE KEY `name` (`name`)                           
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  

CREATE TABLE `perm_data` (                                  
  `id` int(10) unsigned NOT NULL auto_increment,        
  `role_id` int(10) unsigned NOT NULL default '0',  
  `module_id` int(10) unsigned NOT NULL default '0',      
  `dataobject` varchar(64) NOT NULL default '',   
  `description` varchar(255) default NULL, 
  `allow_view` tinyint(4) unsigned NOT NULL default '0',        
  `allow_list` tinyint(4) unsigned NOT NULL default '0',        
  `allow_create` tinyint(4) unsigned NOT NULL default '0',        
  `allow_modify` tinyint(4) unsigned NOT NULL default '0',        
  `allow_delete` tinyint(4) unsigned NOT NULL default '0',            
  `allow_export` tinyint(4) unsigned NOT NULL default '0',            
  `allow_import` tinyint(4) unsigned NOT NULL default '0',            
  PRIMARY KEY  (`id`),                                
  KEY `module_id` (`module_id`)                       
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  


/* permission level: ALL, NO, OWNER */

CREATE TABLE `acl_role_action` (                                  
  `id` int(10) unsigned NOT NULL auto_increment,        
  `role_id` int(10) unsigned NOT NULL default '0',  
  `action_id` int(10) unsigned NOT NULL default '0',              
  `access_level` int(4) unsigned NOT NULL default '0',            
  PRIMARY KEY  (`id`),                                
  KEY `role_id` (`role_id`),                       
  KEY `action_id` (`action_id`)                       
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 

/* this table should be populated by module installation */
/* data action list: access, view, list, create, edit, delete, export, import */
/* custom action list:  ... */

CREATE TABLE `acl_action` (                                  
  `id` int(10) unsigned NOT NULL auto_increment,       
  `module` varchar(64) NOT NULL default '',      
  `resource` varchar(64) NOT NULL default '',      
  `action` varchar(64) NOT NULL default '',   
  `description` varchar(255) default NULL,        
  PRIMARY KEY  (`id`)                                                    
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*
CREATE TABLE `module_action` (                                  
  `id` int(10) unsigned NOT NULL auto_increment,      
  `module_id` int(10) unsigned NOT NULL default '0',      
  `name` varchar(64) NOT NULL default '',   
  `description` varchar(255) default NULL, 
  `default_perm_level_id` int(10) unsigned NOT NULL default '0',        
  PRIMARY KEY  (`id`),                                
  KEY `module_id` (`module_id`)                       
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  

CREATE TABLE `role_perm` (                            
  `id` int(11) NOT NULL auto_increment,               
  `role_id` int(10) unsigned NOT NULL default '0',    
  `module_action_id` int(10) unsigned NOT NULL default '0',    
  `perm_level_id` int(10) unsigned NOT NULL default '0',                                           
  PRIMARY KEY  (`id`),                                
  KEY `role_id` (`role_id`)                                    
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  

CREATE TABLE `perm_level` (                                  
  `id` int(10) unsigned NOT NULL auto_increment,      
  `name` varchar(64) NOT NULL default '',              
  `description` varchar(255) NOT NULL default '', 
  PRIMARY KEY  (`id`),                                
  UNIQUE KEY `name` (`name`)                           
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 
*/